#ifndef VERTEX_H
#define VERTEX_H

class Vertex {
    public:
        float x, y, z;
        Vertex(float, float, float);
};

#endif