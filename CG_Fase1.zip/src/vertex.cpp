#include "vertex.h"

Vertex::Vertex(float xx, float yy, float zz) {
	x = xx;
	y = yy;
	z = zz;
}